#ifndef MERCURY230_H
#define MERCURY230_H

#include <QObject>

//-------------------------
#include "mercury230_global.h"
#include "CListenThread.h"
//-------------------------

class MERCURY230SHARED_EXPORT Mercury230 : QObject
{
    Q_OBJECT
public:
    Mercury230(QObject* parent);
};
extern "C" MERCURY230SHARED_EXPORT QString GetInfoDll(QString &data);
extern "C" MERCURY230SHARED_EXPORT QString GetData(CDispatchThread* pServerObject);
extern "C" MERCURY230SHARED_EXPORT QString GetDataArg(CDispatchThread* pServerObject, QString args);
#endif // MERCURY230_H
