#ifndef GLOBAL
#define GLOBAL
#include <QString>

extern QString DBName;

#endif // GLOBAL

